<!-- ======= Footer ======= -->
<footer id="footer">
      <div class="copy" style="padding-top:20px">Stuckdouga &copy;2025 | All right reserved | This site is intended for over 18 years of age.</div>

          <div class="foot_nav">
              <a href="#">home</a> &nbsp;&bull;&nbsp; 
              <a href="{{ route('latest') }}">galleries</a> &nbsp;&bull;&nbsp; 
              <a href="{{ route('coming') }}">news</a> &nbsp;&bull;&nbsp; 
              <a href="{{ route('threads.index') }}">community</a> &nbsp;&bull;&nbsp; 
              <a href="{{ route('about') }}">about us</a> &nbsp;&bull;&nbsp; 
              <a href="{{ route('resource') }}">resources</a> &nbsp;&bull;&nbsp; 
              <a href="{{ route('account') }}">my account</a> &nbsp;&bull;&nbsp; 
              <a href="{{ route('coming') }}">privacy policy</a> &nbsp;&bull;&nbsp; 
              <a href="{{ route('coming') }}">send feedback</a> 
          </div>

      </div>

</footer><!-- End Footer -->


<!-- Histats.com  START  (aync)-->
<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,4878107,4,0,0,0,00010000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
// var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
// hs.src = ('//s10.histats.com/js15_as.js');
// (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href="/" target="_blank"><img  src="//sstatic1.histats.com/0.gif?4878107&101" alt="free geoip" border="0"></a></noscript>
<!-- Histats.com  END  -->