@extends('admin.partials.master')

@section('title')
    STATISTICS
@endsection
@section('main-content')
    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-sm-xs-12 col-md-12">
                    <div class="card">
                        <div class="card-header justify-content-between">
                            <h4>STATISTICS</h4>
                            <!-- <a href="" class="btn btn-icon icon-left btn-outline-primary">
                                <i class="bx bx-plus"></i>Create New Item</a> -->
                        </div>
                        <div class="card-body">
                            <h5>
                                Coming soon...
                            </h5>   
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>

    
@endsection
