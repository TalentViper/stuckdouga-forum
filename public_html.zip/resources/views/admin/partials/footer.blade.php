<footer class="main-footer">
    <div class="footer-left ">
        {{-- {{settingHelper('admin_panel_copyright_text',\App::getLocale())}} --}}
        &copy;2024 Copyrights STUCKDOUGA Providers | All Rights Reserved
    </div>
    <div class="footer-right">
        {{-- V{{ settingHelper('current_version') }} --}}
    </div>
</footer>
